﻿namespace ASP.NETLab1.Models
{
    public class Dane
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }
    }
}
