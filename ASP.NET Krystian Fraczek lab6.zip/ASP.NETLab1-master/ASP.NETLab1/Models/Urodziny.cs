﻿namespace ASP.NETLab1.Models
{
    public class Urodziny
    {
        public int Id { get; set; }

        public string Imie { get; set; }

        public int Rok { get; set; }
    }
}
